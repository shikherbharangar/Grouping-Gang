# Validation and release checklist

## V1.0 baseline (recorded before V1.1 changes)

- Node.js 24.19.0; Vite 8.3.4; TypeScript 6.0.3; Vitest 5.0.4.
- Production build and strict type check completed.
- ESLint and Prettier checks completed.
- **88 Vitest tests**: assignment invariants for all ten slots, conflicts, explicit swaps, persistence, version migration, invalid storage, session-scoped identity, duplicate names, membership evidence, idempotent reconciliation, duplicate events, worker restart, captured-tab movement, collapse handling, multiple windows, pinned/private/extension tab rejection, failure recovery, missing-assignment retention, metadata recreation, explicit single-tab restoration, interrupted-operation journaling, concurrent recovery prevention, theme persistence, keyboard decisions, manifest and icon integrity.
- **22 Chromium-rendered UI checks**, with test-only mocked Chrome APIs: settings and switcher rendering, ten slots, number zero, missing/ambiguous states, assignment/reassignment, explicit destructive cancellation, recovery confirmation, correct command context, failure UI, arrows/Tab/Enter, Escape, manual/system appearance changes, reduced motion, transient browser-event refresh, long titles, popup dimensions, responsive settings, and no uncaught page errors.
- Screenshots of the actual built DOM/CSS inspected in light and dark themes; settings and recovery dialog also inspected. Fixed a long-title grid overflow found during review. Screenshots use clearly isolated test fixtures; production never supplies sample groups.

Commands:

```sh
npm ci
npm run build
npm run typecheck
npm run lint
npm run test
npm run format:check
npm run test:browser
```

UI screenshots are generated under ignored `artifacts/`. The built extension is under ignored `dist/`. The dependency lockfile is supplied with the source. Installation was exercised with `npm ci` to verify lockfile repeatability.

## Real-browser limitation

The installed Chromium is **154.0.8037.57 on Linux**. Launching it with unpacked-extension flags produced no extension worker. A browser-level DevTools `Extensions.loadUnpacked` request returned:

> Loading of unpacked extensions is disabled by the administrator.

The restriction was not changed or bypassed. Brave/macOS is not installed. **No real Brave behavior is recorded as passed**, and no simulated API result is presented as proof of browser grouping or session restoration. Additional browser downloads were also blocked by network policy; they are not a dependency of the shipped extension.

V1.1 re-ran the same load probe on 14 October 2026 and received the same administrator-policy rejection. No real Brave checks passed. The production artifacts are prepared for local installation. Release acceptance remains conditional on the following tests on a Brave installation that permits unpacked extensions.

## Brave/macOS manual acceptance

Use a disposable Brave profile with ordinary test webpages. Load `dist` through `brave://extensions`. Inspect the extension's error list and its service-worker console after each failing check. Record Brave/macOS versions, actual shortcut, observed result, and any exception.

| Check                    | Steps and expected result                                                                                                                                                                                                                                                               |
| ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Manifest and assets      | Load `dist`. No manifest/worker/CSP errors. Icons and Paper Mono display without network requests. Settings and toolbar popup open.                                                                                                                                                     |
| Shortcut                 | With a webpage active, press Command–Shift–Period. If unassigned, set a free combination at `brave://extensions/shortcuts`. The actual shortcut appears in settings and opens the search launcher. Test both the new Open Grouping Gang command and any retained legacy action binding. |
| Empty registry           | First use with no registry shows an editable one-action proposal. With an intentionally empty returning registry, search is focused and empty-number activation gives assignment guidance without creating a group.                                                                     |
| All ten numbers          | Create ten groups; assign 1–9 and 0. For each number, activate an ungrouped webpage, open the popup and press it. The same tab/URL appears in that exact group; popup closes after success. No extra tabs are created.                                                                  |
| Dismissal                | Open, press Escape, and repeat by clicking outside. No move. Keyboard focus returns to the previous browser context where Brave permits it.                                                                                                                                             |
| Navigation               | Arrows wrap through assigned/filtered results while search keeps focus. Enter moves to the selected result. Tab reaches footer controls; Enter there invokes only that control. Focus remains visible.                                                                                  |
| Collapsed group          | Collapse an assigned group, move a page into it. The existing group is reused, expanded, and shows that page; no duplicate appears. Title/color stay unchanged.                                                                                                                         |
| Multi-window             | Assign a group in another normal window. Move a tab. It joins that group, destination window focuses, URL is unchanged, source-window last-tab handling remains acceptable.                                                                                                             |
| Pinned and stale source  | A pinned source produces an error and stays pinned. Change the active tab while a request is pending: another tab must never be substituted for the captured ID; stale contexts should be rejected.                                                                                     |
| Renaming and movement    | Rename/recolor/move an assigned group within a browser session. Number and UUID remain stable; settings update. Collapse/expand while settings is open: status updates without manual refresh.                                                                                          |
| Missing group            | Close every tab in an assigned group. Its number remains reserved and shows Missing. Opening/dismissing the switcher does not recreate it.                                                                                                                                              |
| Metadata recreation      | Select a missing number: recreation starts immediately without a dialog. Launcher: current tab is grouped under saved title/color, and a recreation/Undo banner appears. Explicit Settings recreation: exactly one blank tab is created. Previous tabs remain closed.                   |
| Single-tab recovery      | Close a regular test webpage, open missing-destination recovery, explicitly select that individual tab and confirm. Only that tab reopens; it joins the recreated group. A closed window must never appear as a recovery choice.                                                        |
| Ambiguity                | Create duplicate-title/color groups, restart Brave, then open settings. Destinations need explicit confirmation rather than automatically choosing a match. Binding one group to two numbers is refused.                                                                                |
| Browser restart / reload | Restart Brave or reload the extension. Numbers/preferences survive. Live group IDs are no longer trusted; confirm bindings. Verify a normal worker suspend/restart within the same browser session preserves trusted bindings.                                                          |
| Operation failure        | Attempt a move while a tab/group disappears or is being dragged. Show an error, keep assignment, reconcile state, and allow a deliberate retry. No false success.                                                                                                                       |
| Interrupted recovery     | In a disposable profile, terminate the worker during recreation. A later request must block duplicate creation and provide a binding/forget path. Inspect existing groups before resolving.                                                                                             |
| Assignment management    | Transfer a number to an occupied number: assignments swap. Forget/reset ask for confirmation. Cancel leaves data intact; confirm changes only registry/preferences, not browser tabs.                                                                                                   |
| Appearance               | Test light/dark/system in settings and popup, restart browser, change macOS appearance while system mode is active. No incorrect-theme flash; names/errors/focus remain readable.                                                                                                       |
| Motion and accessibility | Test macOS Reduce Motion, immediate number input during opening, long names, popup at reduced display height, all dialogs with Tab/Shift-Tab/Escape, and VoiceOver labels/status announcements.                                                                                         |

A user-confirmed binding is required after browser-session identity expires; this is expected, not a promise of automatic saved-group matching. Do not mark the full release accepted until these real-browser checks are recorded.

## V1.1 checks executed

- **141 Vitest tests across 6 files**, preserving the original 88 checks (updating version/manifest expectations where required). New coverage includes deterministic actual-position ordering, one-time setup, V1/V2 migration, stable automatic assignment, disabled/full-slot cases, auto-assignment Undo/conflicts, search ranking/numeric queries, pre-open source handoff, coalesced launcher opens, failed handoff retry, direct missing recreation, captured/stale sources, same/cross-window Undo, original group/window loss, changed/pinned/closed tabs, expiration, worker restart, and single-consumption failure handling.
- **35 Chromium-rendered UI checks** against the actual built interface with explicit API doubles. These retain the applicable baseline checks and add search focus/filtering, digits as query input, two-stage Escape, selection validity, double-Enter prevention, early number input during delayed state loading, editable first-use mapping with swaps, direct missing activation without confirmation, temporary/expired notices, last-move/assignment Undo controls, and configurable new-group assignment.
- Native-notification adapter tests verify text/button routing, five-second clearing, duplicate/expired notices, startup cleanup and graceful notification denial. They do not validate OS delivery.
- Build, strict type checking, ESLint and Prettier pass. Node and dependency versions remain as in the baseline; no dependencies were added. Version is 1.1.0 and minimum Chromium is 127.
- Actual rendered light/dark launcher screenshots, first-use proposal and Undo state were inspected. Launcher width is 560 px; five-result content is about 340 px tall and ten-result scrolling is bounded. Cached metadata is marked Checking and cannot authorize a move before worker reconciliation.

Run the same commands listed above. `artifacts/switcher-light.png`, `switcher-dark.png`, `setup-v1.1.png`, `undo-v1.1.png`, and the settings/recovery screenshots come from the **mocked browser UI runner**, not a loaded Brave extension. No V1.1 Git push, PR or artifact publication was performed.

## Additional V1.1 Brave/macOS acceptance

| Check                 | Steps and expected result                                                                                                                                                                                                                                                                                                                              |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Fresh setup order     | In a disposable profile with no registry, create groups in shuffled API-ID order across two windows. Open from the active window; the proposal follows actual strip positions there, then other numeric window IDs. Edit a selection (occupied groups swap), accept once, and verify the mapping. With more than ten groups, only ten are proposed.    |
| Existing-user upgrade | Update the same unpacked extension folder/ID from V1.0. Every UUID/number/theme and pending recovery survives, no setup screen returns, auto assignment starts off. Check/approve the new notifications permission if Brave asks.                                                                                                                      |
| New groups            | Enable auto assignment; create a new group with a free number. Existing/missing numbers stay fixed; the new group receives the next free slot. Dismiss/Undo the banner or use launcher Undo assignment. Disabled mode/full slots leave it unassigned. An ambiguous returning group must not receive a fresh number.                                    |
| Search                | Type mixed-case exact, prefix, word-prefix and substring queries. Verify ordering and stable stored numbers. Type digits in a nonempty query: no move. Backspace to empty: direct number keys resume. Missing groups stay searchable.                                                                                                                  |
| Keyboard              | Arrow through a filtered list, change the query so the current selection disappears, then Enter. It must act only on a valid displayed selection. First Escape clears a query; second closes. Rapid Enter/key-repeat/clicks perform one operation.                                                                                                     |
| Loading               | Suspend the worker, reopen the launcher and type a number immediately. It queues until live state is checked, then moves the captured source. Cached entries must never be treated as confirmed live. Corrupt storage must show an actionable settings path.                                                                                           |
| Source and surface    | Test the new named shortcut, any retained legacy action shortcut, toolbar opening, repeated invocation, clicking outside, Escape and success dismissal. Correct source ID must survive opening/focus. No extra window/tab appears. Confirm that toolbar anchoring and native popup focus suit daily use; centred popup-window behavior is not claimed. |
| Direct missing action | Close an assigned group, select its number or a search result. Recreate with the existing source tab and saved metadata without a confirmation dialog. No old tabs/windows reopen; a small confirmation states recreation. Ambiguous/interrupted cases remain blocked.                                                                                 |
| Same-window Undo      | Move an ungrouped tab and a tab from a still-open original group. Use the notification button/body or reopen and choose Undo last move within 30 seconds. Original group/ungrouped membership and approximate position return; unrelated tabs stay open.                                                                                               |
| Cross-window Undo     | Keep the original normal window/group alive with other tabs. Move across windows, then Undo. The same tab returns to its original window and approximate position, then receives focus. If the source window/group closed, report unavailable rather than recreating it.                                                                               |
| Unsafe/failed Undo    | After movement pin, close or move the tab elsewhere, close/move its old group/window, or wait over 30 seconds. Refuse unsafe Undo. Trigger a partial API failure during reversal; a repeated Undo must not repeat mutations. A normal worker restart within 30 seconds can retain Undo; a browser restart cannot.                                      |
| Notifications         | Allow and suppress OS/Brave notifications. With permission, verify the silent, approximately five-second banner and Undo button/body behavior. Without a banner, launcher Undo still works. Dismissal/expiration must never itself mutate a tab.                                                                                                       |
| Themes and motion     | Check both themes, system changes, manual preference persistence, no incorrect-theme flash on reopen, early keyboard input during entrance and reduced motion. Verify the actual macOS popup animation/focus, which CSS cannot fully control.                                                                                                          |

Do not mark full V1.1 release acceptance until these real-browser results are recorded. Domain/operation doubles and rendered UI tests establish development coverage, not native API/focus/notification success.
